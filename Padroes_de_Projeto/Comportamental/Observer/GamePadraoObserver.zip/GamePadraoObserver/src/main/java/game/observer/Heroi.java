
package game.observer;

import game.observer.PersonagemPadrao;

/**
 *
 * @author felipe
 */
public class Heroi extends PersonagemPadrao {

    public Heroi(String pathImage, int posX, int posY) {
        super(pathImage, posX, posY);
        
    }
    
}
